#include "sortbyxasc.h"

SortByXAsc::SortByXAsc()
{

}
